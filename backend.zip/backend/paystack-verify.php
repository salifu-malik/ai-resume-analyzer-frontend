<?php
declare(strict_types=1);
require_once __DIR__ . '/helpers.php';
require_once __DIR__ . '/hashids.php'; // Hashids functions

allow_cors();
start_session();

// Require logged-in user (adjust if webhook/public)
$uid = require_auth();

// Accept GET ?reference= or POST { reference }
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
if ($method === 'OPTIONS') {
    http_response_code(204);
    exit;
}

$reference = '';
if ($method === 'GET') {
    $reference = trim((string)($_GET['reference'] ?? ''));
} elseif ($method === 'POST') {
    $body = require_json();
    $reference = trim((string)($body['reference'] ?? ''));
} else {
    json_response(['error' => 'method'], 405);
}

if ($reference === '') {
    json_response(['error' => 'invalid_input', 'details' => ['reference' => true]], 422);
}

// Verify with Paystack (implement your existing paystack_verify function)
$resp = paystack_verify($reference);

if (!is_array($resp['body'])) {
    json_response([
        'ok' => false,
        'http_status' => $resp['status'],
        'error' => 'bad_gateway',
        'raw' => $resp['raw'],
    ], 502);
}

$body = $resp['body'];
$result = [
    'ok' => true,
    'http_status' => $resp['status'],
    'paystack' => $body,
];

$isOk = isset($body['status']) && $body['status'] === true;
$data = $body['data'] ?? null;
$isSuccess = is_array($data) && (($data['status'] ?? '') === 'success');

if (!$isOk || !$isSuccess) {
    json_response($result);
}

// Decode UID from metadata if frontend sent hashed ID
$metaUid = null;
if (isset($data['metadata'])) {
    $metaArr = is_array($data['metadata']) ? $data['metadata'] : json_decode((string)$data['metadata'], true);
    if (isset($metaArr['uid'])) {
        $metaUid = decode_id($metaArr['uid']);
    }
}

// Ensure UID matches session
if ($metaUid !== null && $metaUid !== $uid) {
    debugLog(['event' => 'verify.mismatch_uid', 'session_uid' => $uid, 'meta_uid' => $metaUid, 'reference' => $reference], 'paystack');
    json_response(['error' => 'uid_mismatch', 'reference' => $reference], 409);
}

// Persist transaction
$pdo = get_pdo();
$stmt = $pdo->prepare('SELECT id FROM transactions WHERE paystack_reference = ? LIMIT 1');
$stmt->execute([$reference]);
if ($stmt->fetch()) {
    $result['created'] = false;
    json_response($result);
}

// Calculate coins
$paid_smallest_unit = (int)($data['amount'] ?? 0);
$unit_price_smallest = 500; // default, fallback
if (isset($metaArr['unit_price_pesewas']) && (int)$metaArr['unit_price_pesewas'] > 0) {
    $unit_price_smallest = (int)$metaArr['unit_price_pesewas'];
}
$coins_to_credit = intdiv($paid_smallest_unit, $unit_price_smallest);
$amount_major = intdiv($paid_smallest_unit, 100);

if ($coins_to_credit <= 0 || $amount_major <= 0) {
    json_response($result); // nothing to credit
}

// Insert credit transaction and update user balance
$pdo->beginTransaction();
try {
    $desc = 'Top up via Paystack';
    $provider = 'paystack';
    $status = (string)($data['status'] ?? 'success');
    $authCode = (string)($data['authorization']['authorization_code'] ?? '');
    $metaJson = json_encode($data, JSON_UNESCAPED_SLASHES);

    // Insert transaction
    $ins = $pdo->prepare('INSERT INTO transactions 
        (user_id, type, amount, currency, description, provider, paystack_reference, paystack_status, paystack_authorization_code, meta)
        VALUES (?, "credit", ?, ?, ?, ?, ?, ?, ?, ?)');
    $currency = strtoupper((string)($data['currency'] ?? 'NGN'));
    $ins->execute([$uid, $amount_major, $currency, $desc, $provider, $reference, $status, $authCode, $metaJson]);

    // Update user coins
    $upd = $pdo->prepare('UPDATE users SET coins = coins + ? WHERE id = ?');
    $upd->execute([$coins_to_credit, $uid]);

    $pdo->commit();
    $result['created'] = true;
    json_response($result);
} catch (Throwable $e) {
    $pdo->rollBack();
    debugLog(['event' => 'verify.persist_error', 'reference' => $reference, 'error' => $e->getMessage()], 'paystack');
    json_response(['error' => 'persist_failed'], 500);
}
