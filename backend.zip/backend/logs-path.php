<?php
declare(strict_types=1);
require_once __DIR__ . '/helpers.php';

// Allow CORS and start session
allow_cors();
start_session();

// Require auth like other endpoints (adjust if you want it public)
$uid = require_auth();

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'GET') {
    json_response(['error' => 'method'], 405);
}

$dir = debug_log_dir();
$exists = is_dir($dir);
$writable = $exists && is_writable($dir);

// List recent log files in the directory (names + sizes), capped to 50
$files = [];
if ($exists) {
    foreach (scandir($dir) ?: [] as $name) {
        if ($name === '.' || $name === '..') continue;
        $path = $dir . DIRECTORY_SEPARATOR . $name;
        if (is_file($path)) {
            $files[] = [
                'name' => $name,
                'size' => filesize($path) ?: 0,
                'mtime' => filemtime($path) ?: 0,
            ];
        }
    }
    // Sort by modified time desc
    usort($files, fn($a, $b) => ($b['mtime'] <=> $a['mtime']));
    $files = array_slice($files, 0, 50);
}

json_response([
    'ok' => true,
    'dir' => $dir,
    'exists' => $exists,
    'writable' => $writable,
    'files' => $files,
]);
