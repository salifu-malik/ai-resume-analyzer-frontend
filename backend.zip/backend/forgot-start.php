<?php
declare(strict_types=1);

require_once __DIR__ . '/helpers.php';

allow_cors();

// Public endpoint (no auth). Handles password reset start.
// Security goals:
// - Do not reveal whether an email exists (respond with { ok: true } either way).
// - Only send code for verified accounts.

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'OPTIONS') { http_response_code(204); exit; }
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
    json_response(['error' => 'method not allowed'], 405);
}

$body = require_json();
$email = trim((string)($body['email'] ?? ''));

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    // Keep response generic to avoid enumeration
    json_response(['ok' => true]);
}

$pdo = get_pdo();

// Ensure columns exist for reset flow (MariaDB 10.4 supports IF NOT EXISTS)
try {
    $pdo->exec(
        "ALTER TABLE users\n" .
        "  ADD COLUMN IF NOT EXISTS reset_code_hash VARCHAR(255) NULL AFTER verify_expires,\n" .
        "  ADD COLUMN IF NOT EXISTS reset_code_expires INT NULL AFTER reset_code_hash,\n" .
        "  ADD COLUMN IF NOT EXISTS reset_token VARCHAR(64) NULL AFTER reset_code_expires,\n" .
        "  ADD COLUMN IF NOT EXISTS reset_token_expires INT NULL AFTER reset_token"
    );
} catch (Throwable $_) {
    // Ignore if fails; columns may already exist or permissions restricted.
}

try {
    $stmt = $pdo->prepare('SELECT id, is_verify FROM users WHERE email = ?');
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if ($user && (int)$user['is_verify'] === 1) {
        // Generate a 6-character uppercase alphanumeric code.
        // Note: Frontend normalizes to A–Z0–9, so avoid special characters.
        $alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789!@#$%&*'; // exclude confusing chars like 0/O/1/I
        $code = '';
        for ($i = 0; $i < 6; $i++) {
            $code .= $alphabet[random_int(0, strlen($alphabet) - 1)];
        }

        $hash = password_hash($code, PASSWORD_DEFAULT);
        $expires = time() + 5 * 60; // 10 minutes

        $upd = $pdo->prepare('UPDATE users SET reset_code_hash = ?, reset_code_expires = ?, reset_token = NULL, reset_token_expires = NULL WHERE id = ?');
        $upd->execute([$hash, $expires, (int)$user['id']]);

        // Send the code via email
        $subject = 'Password reset code';
        $bodyHtml = '<p>Your password reset code is:</p>' .
            '<p style="font-size:20px;letter-spacing:3px;"><strong>' . htmlspecialchars($code, ENT_QUOTES, 'UTF-8') . '</strong></p>' .
            '<p>This code will expire in 5 minutes. If you did not request this, you can ignore this email.</p>';
        mailer_send($email, $subject, $bodyHtml, true, null);
    }
} catch (Throwable $_e) {
    // Do not leak errors to the client; keep response generic
}

json_response(['ok' => true]);
