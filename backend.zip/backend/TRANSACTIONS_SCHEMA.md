Transactions table for wallet + Paystack

Overview
- This schema supports your existing wallet transactions (credit/debit) and adds optional fields to store Paystack-specific details for server-side initialization/verification and future webhook updates.
- It is compatible with the current PHP code (add-coins.php, spend-coins.php, transactions.php), which only requires the core columns. New columns are nullable.

Core columns (already used by your PHP)
- id: BIGINT UNSIGNED, primary key
- user_id: BIGINT UNSIGNED, references users.id (CASCADE on delete)
- type: ENUM('credit','debit')
- amount: INT (store smallest unit, e.g., kobo)
- description: VARCHAR(255) NULL
- created_at: TIMESTAMP DEFAULT CURRENT_TIMESTAMP

Paystack-related columns (optional for manual rows)
- provider: VARCHAR(32) NULL DEFAULT NULL (set to 'paystack' only for Paystack-driven rows)
- paystack_reference: VARCHAR(100) NULL (index for lookups)
- paystack_status: VARCHAR(32) NULL (e.g., success, failed, abandoned)
- paystack_authorization_code: VARCHAR(100) NULL (if you need to save authorization)
- currency: CHAR(3) NOT NULL DEFAULT 'NGN'
- meta: TEXT NULL (store JSON snapshot or notes)
- updated_at: TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP

Recommended indexes
- user_id (filter per user and ordering)
- created_at (recent listings)
- type (optional)
- paystack_reference (fast verify/reconciliation)

SQL migration
- See migrations/001_transactions.sql for:
  - CREATE TABLE IF NOT EXISTS transactions ... (full definition)
  - Commented ALTER TABLE statements to extend an existing minimal table safely

Notes
- Amounts are integers to avoid floating-point rounding (store kobo).
- If you later add a webhook handler, you can locate a row by paystack_reference and update paystack_status/meta accordingly.
- Currency defaults to NGN but can be set per transaction in case you support others.
