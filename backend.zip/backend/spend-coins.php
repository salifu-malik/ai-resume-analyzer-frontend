<?php
declare(strict_types=1);
require_once __DIR__ . '/helpers.php';
allow_cors();
start_session();

$uid = require_auth();
require_verified();
if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_response(['error' => 'method not allowed'], 405);
$body = require_json();
$amount = (int)($body['amount'] ?? 0); // number of coins to spend
$desc = trim((string)($body['description'] ?? 'Usage'));
if ($amount <= 0) json_response(['error' => 'bad_amount'], 422);
if ($desc === '') $desc = 'Usage';
if (strlen($desc) > 255) $desc = substr($desc, 0, 255);

$pdo = get_pdo();
$pdo->beginTransaction();
try {
    // Lock the user's row to ensure consistent balance during spend
    $stmt = $pdo->prepare('SELECT coins FROM users WHERE id = ? FOR UPDATE');
    $stmt->execute([$uid]);
    $row = $stmt->fetch();
    $bal = $row ? (int)$row['coins'] : 0;
    if ($bal < $amount) throw new Exception('insufficient');

    // Record a debit transaction. We store amount as the number of coins spent and mark currency as COI (coins)
    $pdo->prepare('INSERT INTO transactions (user_id, type, amount, currency, description) VALUES (?, "debit", ?, ?, ?)')
        ->execute([$uid, $amount, 'COI', $desc]);
    $pdo->prepare('UPDATE users SET coins = coins - ? WHERE id = ?')
        ->execute([$amount, $uid]);
    $pdo->commit();
    json_response(['ok' => true, 'balance' => $bal - $amount]);
} catch (Throwable $e) {
    $pdo->rollBack();
    $code = ($e->getMessage() === 'insufficient') ? 400 : 500;
    json_response(['error' => $e->getMessage()], $code);
}