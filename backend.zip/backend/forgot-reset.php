<?php
declare(strict_types=1);

require_once __DIR__ . '/helpers.php';

allow_cors();

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'OPTIONS') { http_response_code(204); exit; }
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
    json_response(['error' => 'method not allowed'], 405);
}

$body = require_json();
$email = trim((string)($body['email'] ?? ''));
$token = trim((string)($body['token'] ?? ''));
$new   = (string)($body['new_password'] ?? '');
$conf  = (string)($body['confirm_password'] ?? '');

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    json_response(['error' => 'invalid_input'], 422);
}
if ($new === '' || $conf === '') {
    json_response(['error' => 'Password fields required'], 422);
}
if ($new !== $conf) {
    json_response(['error' => 'Password mismatch'], 422);
}
if (strlen($new) < 6) {
    json_response(['error' => 'Weak password', 'min' => 6], 422);
}
if ($token === '' || strlen($token) < 32) { // basic sanity
    json_response(['error' => 'Invalid or expired token'], 400);
}

$pdo = get_pdo();

try {
    $stmt = $pdo->prepare('SELECT id, is_verify, reset_token, reset_token_expires FROM users WHERE email = ?');
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if (!$user || (int)$user['is_verify'] !== 1) {
        json_response(['error' => 'Invalid or expired token'], 400);
    }

    $dbTok = (string)($user['reset_token'] ?? '');
    $exp   = (int)($user['reset_token_expires'] ?? 0);
    if ($dbTok === '' || !hash_equals($dbTok, $token) || $exp < time()) {
        json_response(['error' => 'Invalid or expired token'], 400);
    }

    $newHash = password_hash($new, PASSWORD_DEFAULT);

    $upd = $pdo->prepare('UPDATE users SET password_hash = ?, reset_token = NULL, reset_token_expires = NULL, reset_code_hash = NULL, reset_code_expires = NULL WHERE id = ?');
    $upd->execute([$newHash, (int)$user['id']]);

    json_response(['ok' => true]);
} catch (Throwable $e) {
    debugLog(['event' => 'forgot.reset.error', 'email' => $email, 'msg' => $e->getMessage()], 'backend');
    json_response(['error' => 'server_error'], 500);
}
