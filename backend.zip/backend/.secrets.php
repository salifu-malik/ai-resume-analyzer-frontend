<?php
// Local development secrets (do NOT commit real production secrets)
// This file is loaded by config.php if present.

// PAYSTACK SECRET KEY.
define('PAYSTACK_SECRET', 'sk_test_1a54d79e1529f90aa01367944c88db35d14e3a17');

// Gemini (Google Generative Language) API key for local development.
//  GEMINI_API_KEY.
define('GEMINI_API_KEY', 'AIzaSyDIuN9GrvI2CRvQTl50e0uJVMixsUXktnQ');

//HASHIDS SALTS ENCODED KEY
define('HASHED_SALT', '356a988d39d4f63ff48f18a9a3e356a9f4a7160db40bcafb93a3366340a63e33738de6b81c8cd81eaecf13d063e3d6578db127518edb0d0c3be9ea47237a28be');

//SERVER-TO-SERVER ENCRYPTION COMMUNICATION KEY
define('SERVER_API_KEY', '8cdc64c273fff937a5995489291cc7f1094c4d6c404fe551b4e6a32e316ce76200d09ad599d90a0672317225c0247dae93ec38a55989929a7fa079517b7b8c2c');




//EMAIL CONFIG DETAILS
define('SMTP_SECURE', 'ssl');
define('SMTP_PORT', 465);
define('SMTP_USERNAME', 'kelvinantwi101@gmail.com');
define('SMTP_PASSWORD', 'cerq mgzc nogd ghfo');
define('FROM_EMAIL', 'kelvinantwi101@gmail.com');
define('FROM_NAME', 'RESUCHECK');

//wpgj fjta tfst vohj