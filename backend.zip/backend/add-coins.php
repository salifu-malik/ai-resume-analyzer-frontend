<?php
declare(strict_types=1);
require_once __DIR__ . '/helpers.php';

allow_cors();
start_session();

$uid = require_auth();
require_verified();


if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_response(['error' => 'method not allowed'], 405);
$body = require_json();
$amount = (int)($body['amount'] ?? 0);
$desc = trim($body['description'] ?? 'Top up');
if ($amount <= 0) json_response(['error' => 'bad_amount'], 422);

$pdo = get_pdo();
$pdo->beginTransaction();
try {
    $pdo->prepare('INSERT INTO transactions (user_id, type, amount, description) VALUES (?, "credit", ?, ?)')
        ->execute([$uid, $amount, $desc]);
    $pdo->prepare('UPDATE users SET coins = coins + ? WHERE id = ?')
        ->execute([$amount, $uid]);
    $pdo->commit();
    json_response(['ok' => true]);
} catch (Throwable $e) {
    $pdo->rollBack();
    json_response(['error' => 'server_error'], 500);
}