<?php
declare(strict_types=1);
require_once __DIR__ . '/helpers.php';

// Public endpoint (no auth). Allows a user to request a password reset code via email.
allow_cors();
start_session();

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
if ($method === 'OPTIONS') { http_response_code(204); exit; }
if ($method !== 'POST') json_response(['error' => 'method'], 405);

$body = require_json();
$email = strtolower(trim((string)($body['email'] ?? '')));
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    json_response(['error' => 'invalid_input', 'details' => ['email' => true]], 422);
}

$pdo = get_pdo();

// Ensure helper table exists (idempotent)
try {
    $pdo->exec(
        "CREATE TABLE IF NOT EXISTS password_resets (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            email VARCHAR(255) NOT NULL,
            code_hash VARCHAR(255) NOT NULL,
            expires_at DATETIME NOT NULL,
            attempts INT NOT NULL DEFAULT 0,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY idx_reset_email (email),
            KEY idx_reset_expires (expires_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    );
} catch (Throwable $e) {
    debugLog(['event' => 'reset.ensure_table_error', 'error' => $e->getMessage()], 'backend');
    json_response(['error' => 'server_error'], 500);
}

// Generate a 6-character alphanumeric code (A-Z0-9)
$alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // avoid ambiguous chars
$code = '';
for ($i = 0; $i < 6; $i++) {
    $code .= $alphabet[random_int(0, strlen($alphabet) - 1)];
}

$hash = password_hash($code, PASSWORD_DEFAULT);
$expiresAt = (new DateTime('+5 minutes'))->format('Y-m-d H:i:s');

try {
    // Upsert-like behavior: delete previous rows for this email, then insert a new one
    $pdo->beginTransaction();
    $del = $pdo->prepare('DELETE FROM password_resets WHERE email = ?');
    $del->execute([$email]);
    $ins = $pdo->prepare('INSERT INTO password_resets (email, code_hash, expires_at, attempts) VALUES (?, ?, ?, 0)');
    $ins->execute([$email, $hash, $expiresAt]);
    $pdo->commit();
} catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    debugLog(['event' => 'reset.insert_error', 'email' => $email, 'error' => $e->getMessage()], 'backend');
    json_response(['error' => 'server_error'], 500);
}

// Attempt to send email using PHPMailer via configured SMTP.
// Always log the action, but never include the code in the API response body.
$subject = 'RESUCHECK - Password Reset Code';
$plain = "Use this code to reset your password: {$code}\n\nThis code expires in 5 minutes.";
$html = '<p>Use this code to reset your password: <strong>' . htmlspecialchars($code, ENT_QUOTES, 'UTF-8') . "</strong></p>"
      . '<p>This code expires in 5 minutes.</p>';

$sent = false;
try {
    // Prefer HTML email with a plain-text AltBody fallback inside mailer_send
    $sent = mailer_send($email, $subject, $html, true);
    if (!$sent) {
        // Fallback to plain text if HTML fails unexpectedly
        $sent = mailer_send($email, $subject, $plain, false);
    }
} catch (Throwable $e) {
    // ignore; will be logged below
}

// Log the fact that a reset email was requested. We include the code in logs to aid development,
// but consider masking/removing in production.
debugLog([
    'event' => 'password_reset.request',
    'email' => $email,
    'sent' => $sent,
    'code' => $code,
    'expires_at' => $expiresAt,
], 'backend');

// For security, do not reveal whether the email exists in the system. Return a generic OK.
json_response(['ok' => true]);
