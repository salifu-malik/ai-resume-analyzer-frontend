<?php
//declare(strict_types=1);
//
//// IMPORTANT: Do not commit real secrets. Keep .secrets.php out of version control.
//// In production, prefer setting environment variables on the server instead.
//($__secrets = __DIR__ . '/.secrets.php') && is_file($__secrets) && @include_once $__secrets;
//
//
//const DB_HOST = '127.0.0.1';
//const DB_NAME = 'resume_app';
//const DB_USER = 'Mankind';
//const DB_PASS = 'Ptwamy0706!';
//
///**
// * Get a shared PDO instance.
// */
//function get_pdo(): PDO {
//    static $pdo = null;
//    if ($pdo === null) {
//        $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4';
//        $pdo = new PDO($dsn, DB_USER, DB_PASS, [
//            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
//            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
//        ]);
//    }
//    return $pdo;
//}
//
///**
// * CORS helper for dev (tighten for production)
//
// * Allow CORS headers for development.
// */
//function allow_cors(): void {
//    $origin = $_SERVER['HTTP_ORIGIN'] ?? 'http://localhost:5173';
//    header('Access-Control-Allow-Origin: ' . $origin);
//    header('Access-Control-Allow-Credentials: true');
//    header('Access-Control-Allow-Headers: Content-Type, Authorization');
//    header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
//    if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
//        http_response_code(204);
//        exit;
//    }
//}
//
///**
// * Secure CORS helper with optional server-to-server protection.
// *
// * Features:
// * - Only allows specific origins (frontend URLs) or blocks all others.
// * - Handles preflight OPTIONS requests automatically.
// * - Can enforce server API key for trusted server requests.
// */
//
////function allow_cors(array $allowed_origins = []): void {
////    // Fallback dev origin
////    if (empty($allowed_origins)) {
////        $allowed_origins = [
////            'http://localhost:5173',
//////            'http://127.0.0.1:5173',
//////            'https://your-production-frontend.com',
////
////        ];
////    }
////
////    $origin = $_SERVER['HTTP_ORIGIN'] ?? '';
////
////    if (in_array($origin, $allowed_origins, true)) {
////        header('Access-Control-Allow-Origin: ' . $origin);
////        header('Access-Control-Allow-Credentials: true');
////        header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Server-Key');
////        header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
////    } else {
////        // Deny unknown origins (optional: log attempts)
////        http_response_code(403);
////        echo json_encode(['error' => 'CORS origin not allowed', 'origin' => $origin]);
////        exit;
////    }
////
////    // OPTIONS preflight requests: respond and exit immediately
////    if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
////        http_response_code(204);
////        exit;
////    }
//}
//
///**
// * Enforce API key for server-to-server requests.
// */
//function require_server_key(): void {
//    $expected = env('SERVER_API_KEY')
//        ?: (defined('SERVER_API_KEY') ? SERVER_API_KEY : null);
//
//    if (!$expected) {
//        http_response_code(500);
//        echo json_encode(['error' => 'SERVER_API_KEY not configured']);
//        exit;
//    }
//
//    $received = $_SERVER['HTTP_X_SERVER_KEY'] ?? '';
//
//    if (!hash_equals($expected, $received)) {
//        http_response_code(403);
//        echo json_encode(['error' => 'Forbidden ']);
//        exit;
//    }
//}
//
///**
// * Optional: IP whitelist for additional server security.
// */
//function require_allowed_ip(array $allowed_ips = []): void {
//    if (empty($allowed_ips)) {
//        $allowed_ips = [
//            '127.0.0.1', // local
//            '::1',       // IPv6 local
//            // Add your real server IPs here
//        ];
//    }
//
//    $ip = $_SERVER['REMOTE_ADDR'] ?? '';
//
//    if (!in_array($ip, $allowed_ips, true)) {
//        http_response_code(403);
//        echo json_encode([
//            'error' => ' IP not allowed',
//            'your_ip' => $ip
//        ]);
//        exit;
//    }
//}
//
//
//
///**
// * Start a session with reasonable defaults.
// */
//function start_session(): void {
//    if (session_status() === PHP_SESSION_NONE) {
//        // Configure cookie params. Use array signature when available (PHP >= 7.3),
//        // otherwise fall back to legacy parameters for PHP 7.0–7.2.
//        if (PHP_VERSION_ID >= 70300) {
//            session_set_cookie_params([
//                'lifetime' => 60*60*24*7,
//                'path' => '/',
//                'domain' => '',
//                'secure' => false, // set true on HTTPS
//                'httponly' => true,
//                'samesite' => 'Lax',
//            ]);
//        } else {
//            $lifetime = 60*60*24*7;
//            $path = '/';
//            $domain = '';
//            $secure = false; // set true on HTTPS
//            $httponly = true;
//            @session_set_cookie_params($lifetime, $path, $domain, $secure, $httponly);
//        }
//        session_start();
//    }
//}
//
///**
// * Emit a JSON response and terminate script.
// *
// * @param mixed $data
// */
//function json_response($data, int $status = 200): void {
//    header('Content-Type: application/json');
//    http_response_code($status);
//    echo json_encode($data);
//    exit;
//}
//
///**
// * Read an environment variable in a robust way.
// * Checks getenv(), then $_ENV, then $_SERVER.
// */
//function env(string $key, ?string $default = null): ?string {
//    $val = getenv($key);
//    if ($val !== false) return $val === '' ? $default : $val;
//    if (array_key_exists($key, $_ENV)) return $_ENV[$key] === '' ? $default : (string)$_ENV[$key];
//    if (array_key_exists($key, $_SERVER)) return $_SERVER[$key] === '' ? $default : (string)$_SERVER[$key];
//    return $default;
//}
//
///**
// * Get the Paystack secret key from server environment.
// *
// * Configure in your server as PAYSTACK_SECRET (never expose to frontend).
// * Example (Apache): SetEnv PAYSTACK_SECRET "sk_test_xxx"
// */
//function get_paystack_secret(): string {
//    // 1) Prefer server-provided environment variable
//    $secret = env('PAYSTACK_SECRET');
//
//    // 2) Fallback: allow a local constant from .secrets.php for development
//    if (!$secret && defined('PAYSTACK_SECRET') && PAYSTACK_SECRET !== '') {
//        $secret = PAYSTACK_SECRET;
//    }
//
//    if (!$secret) {
//        // Do not hardcode secrets in source control. Set PAYSTACK_SECRET on the server
//        // or define('PAYSTACK_SECRET', '...') in .secrets.php for local development.
//        throw new RuntimeException('PAYSTACK_SECRET not set (env or .secrets.php)');
//    }
//    return $secret;
//}
//
///**
// * Convenience helper to build headers for Paystack API requests.
// */
//function paystack_headers(): array {
//    return [
//        'Authorization: Bearer ' . get_paystack_secret(),
//        'Content-Type: application/json',
//        'Accept: application/json',
//    ];
//}
//
///* Determine and prepare the log directory (project logs/ or system temp fallback) */
//function debug_log_dir(): string {
//    $primary = __DIR__ . '/logs';
//    if (!is_dir($primary)) {
//        @mkdir($primary, 0775, true);
//    }
//    if (is_dir($primary) && is_writable($primary)) {
//        return $primary;
//    }
//
//    $fallback = rtrim(sys_get_temp_dir(), DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . 'backend-logs';
//    if (!is_dir($fallback)) {
//        @mkdir($fallback, 0777, true);
//    }
//    if (is_dir($fallback) && is_writable($fallback)) {
//        return $fallback;
//    }
//
//    // As a last resort, return primary path even if not writable (caller will fallback to error_log)
//    return $primary;
//}
//
///* Log my activities*/
//function debugLog(mixed $message, string $type = 'debugging')
//{
//    $logDir = debug_log_dir();
//
//    // Log file named by type and current date
//    $file = $logDir . '/' . $type . '-' . date('Y-m-d') . '.log';
//
//    // Format message (handle arrays/objects/strings)
//    if (is_array($message) || is_object($message)) {
//        $formattedMessage = print_r($message, true);
//    } else {
//        $formattedMessage = (string)$message;
//    }
//
//    // Add timestamp to entry
//    $entry = '[' . date('Y-m-d H:i:s') . '] ' . $formattedMessage . PHP_EOL;
//
//    // Try to write to file with locking; if it fails (directory still not writable), fallback to PHP error_log
//    $written = @file_put_contents($file, $entry, FILE_APPEND | LOCK_EX);
//    if ($written === false) {
//        // Fall back to error_log to avoid losing the message entirely
//        @error_log('[backend debugLog ' . $type . '] ' . $formattedMessage);
//    }
//}
//
///**
// * Base URL for Paystack API.
// */
//function paystack_base_url(): string {
//    return 'https://api.paystack.co/';
//}
//
///**
// * Internal helper to mask secrets in headers before logging.
// */
//function mask_headers_for_log(array $headers): array {
//    return array_map(function ($h) {
//        // Mask Authorization: Bearer sk_....
//        if (stripos($h, 'authorization:') === 0) {
//            return 'Authorization: Bearer ***';
//        }
//        return $h;
//    }, $headers);
//}
//
///**
// * Make a Paystack HTTP request with automatic logging via debugLog().
// *
// * @param string $method   HTTP method, e.g., 'GET' or 'POST'
// * @param string $endpoint API endpoint path relative to base, e.g., 'transaction/initialize'
// * @param array|null $payload JSON body for POST/PUT/PATCH; ignored for GET
// * @param array $extraHeaders Additional headers (strings like 'Header: value')
// * @return array{status:int, body:mixed, raw:string}
// */
//function paystack_request(string $method, string $endpoint, ?array $payload = null, array $extraHeaders = []): array {
//    $method = strtoupper($method);
//    $url = rtrim(paystack_base_url(), '/') . '/' . ltrim($endpoint, '/');
//
//    $headers = array_merge(paystack_headers(), $extraHeaders);
//    $maskedHeaders = mask_headers_for_log($headers);
//
//    $body = null;
//    if ($payload !== null && $method !== 'GET') {
//        $body = json_encode($payload, JSON_UNESCAPED_SLASHES);
//    }
//
//    $ch = curl_init($url);
//    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
//    if ($body !== null) {
//        curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
//    }
//    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
//    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
//    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
//
//    $t0 = microtime(true);
//    $resp = curl_exec($ch);
//    $errno = curl_errno($ch);
//    $err = $errno ? curl_error($ch) : null;
//    $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
//    curl_close($ch);
//    $dt = round((microtime(true) - $t0) * 1000);
//
//    // Truncate very large payloads to keep logs manageable
//    $truncate = function (?string $s, int $limit = 4000): ?string {
//        if ($s === null) return null;
//        return strlen($s) > $limit ? substr($s, 0, $limit) . "... (truncated)" : $s;
//    };
//
//    // Log request summary
//    debugLog([
//        'event' => 'paystack.request',
//        'method' => $method,
//        'url' => $url,
//        'headers' => $maskedHeaders,
//        'payload' => $payload,
//    ], 'paystack');
//
//    // Log response or error
//    if ($errno) {
//        debugLog([
//            'event' => 'paystack.response',
//            'duration_ms' => $dt,
//            'http_status' => $status,
//            'error' => $err,
//            'raw' => $truncate($resp),
//        ], 'paystack');
//        return ['status' => $status ?: 0, 'body' => null, 'raw' => (string)$resp];
//    }
//
//    $decoded = null;
//    if (is_string($resp) && $resp !== '') {
//        $decoded = json_decode($resp, true);
//    }
//
//    debugLog([
//        'event' => 'paystack.response',
//        'duration_ms' => $dt,
//        'http_status' => $status,
//        'body' => is_array($decoded) ? $decoded : $truncate($resp),
//    ], 'paystack');
//
//    return ['status' => (int)$status, 'body' => $decoded, 'raw' => (string)$resp];
//}
//
///**
// * Initialize a Paystack transaction and log details.
// * Example $params: ['email' => 'user@example.com', 'amount' => 50000]
// */
//function paystack_initialize(array $params): array {
//    return paystack_request('POST', 'transaction/initialize', $params);
//}
//
///**
// * Verify a Paystack transaction by reference and log details.
// */
//function paystack_verify(string $reference): array {
//    $endpoint = 'transaction/verify/' . rawurlencode($reference);
//    return paystack_request('GET', $endpoint);
//}
//
//// Email Configurations (provided by user)
//define('SMTP_HOST', 'smtp.gmail.com');
//define('SMTP_SECURE', 'ssl'); // 'ssl' | 'tls' | ''
//define('SMTP_PORT', 465);
//define('SMTP_USERNAME', 'kelvinantwi101@gmail.com');
//define('SMTP_PASSWORD', 'wpgj fjta tfst vohj');
//define('FROM_EMAIL', 'kelvinantwi101@gmail.com');
//// Optional friendly name
//if (!defined('FROM_NAME')) {
//    define('FROM_NAME', 'RESUCHECK');
//}
//
///**
// * Send email via PHPMailer using SMTP constants defined above.
// * Returns true on success, false on failure. Logs details via debugLog().
// */
//function mailer_send(string $to, string $subject, string $body, bool $isHtml = false, ?string $replyTo = null): bool {
//    // Load PHPMailer classes (no composer autoload in this project)
//    $base = __DIR__ . '/PHPMailer/src';
//    if (is_file($base . '/PHPMailer.php')) {
//        require_once $base . '/PHPMailer.php';
//        require_once $base . '/SMTP.php';
//        require_once $base . '/Exception.php';
//    }
//
//    // Namespaced class
//    if (!class_exists('PHPMailer\\PHPMailer\\PHPMailer')) {
//        debugLog(['event' => 'mail.error', 'reason' => 'PHPMailer class not found'], 'backend');
//        return false;
//    }
//
//    $mail = new PHPMailer\PHPMailer\PHPMailer(true);
//    try {
//        $mail->isSMTP();
//        $mail->Host = SMTP_HOST;
//        $mail->Port = (int)SMTP_PORT;
//        $mail->SMTPAuth = true;
//        $mail->Username = SMTP_USERNAME;
//        $mail->Password = SMTP_PASSWORD;
//
//        // Map SMTP_SECURE string to PHPMailer constant
//        $secure = strtolower((string)SMTP_SECURE);
//        if ($secure === 'ssl') {
//            $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_SMTPS;
//        } elseif ($secure === 'tls') {
//            $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
//        } else {
//            $mail->SMTPSecure = '';
//        }
//
//        $mail->CharSet = 'UTF-8';
//        $mail->setFrom(FROM_EMAIL, defined('FROM_NAME') ? FROM_NAME : '');
//        if ($replyTo) {
//            $mail->addReplyTo($replyTo);
//        }
//        $mail->addAddress($to);
//
//        $mail->Subject = $subject;
//        if ($isHtml) {
//            $mail->isHTML(true);
//            $mail->Body = $body;
//            // Provide a basic AltBody by stripping tags
//            $mail->AltBody = trim(strip_tags(str_replace(["<br>", "<br/>", "<br />"], "\n", $body)));
//        } else {
//            $mail->isHTML(false);
//            $mail->Body = $body;
//        }
//
//        $ok = $mail->send();
//        debugLog(['event' => 'mail.send', 'to' => $to, 'ok' => $ok, 'subject' => $subject], 'backend');
//        return $ok;
//    } catch (Throwable $e) {
//        debugLog(['event' => 'mail.error', 'to' => $to, 'error' => $e->getMessage()], 'backend');
//        return false;
//    }
//}
//
//// Backward-compat shim: some endpoints may still call mail_send()
//if (!function_exists('mail_send')) {
//    /**
//     * Compatibility wrapper that proxies to PHPMailer-based mailer_send().
//     * Signature kept simple to match usage in this project.
//     */
//    function mail_send(string $to, string $subject, string $message): bool {
//        return mailer_send($to, $subject, $message, false, null);
//    }
//}

declare(strict_types=1);

// IMPORTANT: Do not commit real secrets. Keep .secrets.php out of version control.
// In production, prefer setting environment variables on the server instead.
($__secrets = __DIR__ . '/.secrets.php') && is_file($__secrets) && @include_once $__secrets;


const DB_HOST = '127.0.0.1';
const DB_NAME = 'resume_app';
const DB_USER = 'Mankind';
const DB_PASS = 'Ptwamy0706!';

/**
 * Get a shared PDO instance.
 */
function get_pdo(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4';
        $pdo = new PDO($dsn, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]);
    }
    return $pdo;
}

/**
 * Allow CORS for a strict whitelist of origins.
 *
 * Configure allowed origins via one of:
 * - ALLOWED_ORIGINS constant in .secrets.php (comma-separated)
 * - ALLOWED_ORIGINS env var (comma-separated)
 * Defaults to http://localhost:5173
 */
function allow_cors(): void {
    // Resolve allowed origins list
    $raw = null;
    if (defined('ALLOWED_ORIGINS')) {
        $raw = (string)ALLOWED_ORIGINS;
    } else {
        $raw = env('ALLOWED_ORIGINS', 'http://localhost:5173');
    }
    $allowed = array_values(array_filter(array_map('trim', explode(',', (string)$raw)), function ($o) {
        return $o !== '';
    }));

    $reqOrigin = $_SERVER['HTTP_ORIGIN'] ?? '';
    $allowOrigin = '';
    if ($reqOrigin !== '' && in_array($reqOrigin, $allowed, true)) {
        $allowOrigin = $reqOrigin;
    }

    if ($allowOrigin !== '') {
        header('Access-Control-Allow-Origin: ' . $allowOrigin);
        header('Vary: Origin');
    }

    // Credentials needed for session cookies
    header('Access-Control-Allow-Credentials: true');
    header('Access-Control-Allow-Headers: Content-Type, Authorization, X-CSRF-Token');
    header('Access-Control-Allow-Methods: GET, POST, OPTIONS');

    if (($_SERVER['REQUEST_METHOD'] ?? '') === 'OPTIONS') {
        http_response_code(204);
        exit;
    }
}


/**
 * Start a session with reasonable defaults.
 */
function start_session(): void {
    if (session_status() === PHP_SESSION_NONE) {
        // Configure cookie params. Use array signature when available (PHP >= 7.3),
        // otherwise fall back to legacy parameters for PHP 7.0–7.2.
        if (PHP_VERSION_ID >= 70300) {
            session_set_cookie_params([
                'lifetime' => 60*60*24*7,
                'path' => '/',
                'domain' => '',
                'secure' => false, // set to true on HTTPS/production
                'httponly' => true,
                'samesite' => 'Lax',
            ]);
        } else {
            $lifetime = 60*60*24*7;
            $path = '/';
            $domain = '';
            $secure = false; // set to true on HTTPS/production
            $httponly = true;
            @session_set_cookie_params($lifetime, $path, $domain, $secure, $httponly);
        }
        session_start();
        if (!isset($_SESSION['csrf']) || !is_string($_SESSION['csrf']) || $_SESSION['csrf'] === '') {
            $_SESSION['csrf'] = bin2hex(random_bytes(32));
        }
    }
}

/**
 * Emit a JSON response and terminate script.
 *
 * @param mixed $data
 */
function json_response($data, int $status = 200): void {
    header('Content-Type: application/json');
    http_response_code($status);
    echo json_encode($data);
    exit;
}

/**
 * Get the CSRF token for the current session (generate in start_session()).
 */
function get_csrf_token(): string {
    return isset($_SESSION['csrf']) && is_string($_SESSION['csrf']) ? $_SESSION['csrf'] : '';
}

/**
 * Require a valid CSRF token for state-changing requests.
 * Not globally enforced to avoid breaking existing clients; call from endpoints after require_auth().
 */
function require_csrf(): void {
    $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
    if ($method === 'GET' || $method === 'OPTIONS') return;

    $sessionToken = get_csrf_token();
    $headerToken = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
    if (!$sessionToken || !$headerToken || !hash_equals($sessionToken, $headerToken)) {
        json_response(['error' => 'csrf invalid'], 403);
    }
}

/**
 * Read an environment variable in a robust way.
 * Checks getenv(), then $_ENV, then $_SERVER.
 */
function env(string $key, ?string $default = null): ?string {
    $val = getenv($key);
    if ($val !== false) return $val === '' ? $default : $val;
    if (array_key_exists($key, $_ENV)) return $_ENV[$key] === '' ? $default : (string)$_ENV[$key];
    if (array_key_exists($key, $_SERVER)) return $_SERVER[$key] === '' ? $default : (string)$_SERVER[$key];
    return $default;
}

/**
 * Get the Paystack secret key from server environment.
 *
 * Configure in your server as PAYSTACK_SECRET (never expose to frontend).
 * Example (Apache): SetEnv PAYSTACK_SECRET "sk_test_xxx"
 */
function get_paystack_secret(): string {
    // 1) Prefer server-provided environment variable
    $secret = env('PAYSTACK_SECRET');

    // 2) Fallback: allow a local constant from .secrets.php for development
    if (!$secret && defined('PAYSTACK_SECRET') && PAYSTACK_SECRET !== '') {
        $secret = PAYSTACK_SECRET;
    }

    if (!$secret) {
        // Do not hardcode secrets in source control. Set PAYSTACK_SECRET on the server
        // or define('PAYSTACK_SECRET', '...') in .secrets.php for local development.
        throw new RuntimeException('PAYSTACK_SECRET not set (env or .secrets.php)');
    }
    return $secret;
}

/**
 * Convenience helper to build headers for Paystack API requests.
 */
function paystack_headers(): array {
    return [
        'Authorization: Bearer ' . get_paystack_secret(),
        'Content-Type: application/json',
        'Accept: application/json',
    ];
}

/* Determine and prepare the log directory (project logs/ or system temp fallback) */
function debug_log_dir(): string {
    $primary = __DIR__ . '/logs';
    if (!is_dir($primary)) {
        @mkdir($primary, 0775, true);
    }
    if (is_dir($primary) && is_writable($primary)) {
        return $primary;
    }

    $fallback = rtrim(sys_get_temp_dir(), DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . 'backend-logs';
    if (!is_dir($fallback)) {
        @mkdir($fallback, 0777, true);
    }
    if (is_dir($fallback) && is_writable($fallback)) {
        return $fallback;
    }

    // As a last resort, return primary path even if not writable (caller will fallback to error_log)
    return $primary;
}

/* Log my activities*/
function debugLog(mixed $message, string $type = 'debugging')
{
    $logDir = debug_log_dir();

    // Log file named by type and current date
    $file = $logDir . '/' . $type . '-' . date('Y-m-d') . '.log';

    // Format message (handle arrays/objects/strings)
    if (is_array($message) || is_object($message)) {
        $formattedMessage = print_r($message, true);
    } else {
        $formattedMessage = (string)$message;
    }

    // Add timestamp to entry
    $entry = '[' . date('Y-m-d H:i:s') . '] ' . $formattedMessage . PHP_EOL;

    // Try to write to file with locking; if it fails (directory still not writable), fallback to PHP error_log
    $written = @file_put_contents($file, $entry, FILE_APPEND | LOCK_EX);
    if ($written === false) {
        // Fall back to error_log to avoid losing the message entirely
        @error_log('[backend debugLog ' . $type . '] ' . $formattedMessage);
    }
}

/**
 * Base URL for Paystack API.
 */
function paystack_base_url(): string {
    return 'https://api.paystack.co/';
}

/**
 * Internal helper to mask secrets in headers before logging.
 */
function mask_headers_for_log(array $headers): array {
    return array_map(function ($h) {
        // Mask Authorization: Bearer sk_....
        if (stripos($h, 'authorization:') === 0) {
            return 'Authorization: Bearer ***';
        }
        return $h;
    }, $headers);
}

/**
 * Make a Paystack HTTP request with automatic logging via debugLog().
 *
 * @param string $method   HTTP method, e.g., 'GET' or 'POST'
 * @param string $endpoint API endpoint path relative to base, e.g., 'transaction/initialize'
 * @param array|null $payload JSON body for POST/PUT/PATCH; ignored for GET
 * @param array $extraHeaders Additional headers (strings like 'Header: value')
 * @return array{status:int, body:mixed, raw:string}
 */
function paystack_request(string $method, string $endpoint, ?array $payload = null, array $extraHeaders = []): array {
    $method = strtoupper($method);
    $url = rtrim(paystack_base_url(), '/') . '/' . ltrim($endpoint, '/');

    $headers = array_merge(paystack_headers(), $extraHeaders);
    $maskedHeaders = mask_headers_for_log($headers);

    $body = null;
    if ($payload !== null && $method !== 'GET') {
        $body = json_encode($payload, JSON_UNESCAPED_SLASHES);
    }

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
    if ($body !== null) {
        curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
    }
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);

    $t0 = microtime(true);
    $resp = curl_exec($ch);
    $errno = curl_errno($ch);
    $err = $errno ? curl_error($ch) : null;
    $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    $dt = round((microtime(true) - $t0) * 1000);

    // Truncate very large payloads to keep logs manageable
    $truncate = function (?string $s, int $limit = 4000): ?string {
        if ($s === null) return null;
        return strlen($s) > $limit ? substr($s, 0, $limit) . "... (truncated)" : $s;
    };

    // Log request summary
    debugLog([
        'event' => 'paystack.request',
        'method' => $method,
        'url' => $url,
        'headers' => $maskedHeaders,
        'payload' => $payload,
    ], 'paystack');

    // Log response or error
    if ($errno) {
        debugLog([
            'event' => 'paystack.response',
            'duration_ms' => $dt,
            'http_status' => $status,
            'error' => $err,
            'raw' => $truncate($resp),
        ], 'paystack');
        return ['status' => $status ?: 0, 'body' => null, 'raw' => (string)$resp];
    }

    $decoded = null;
    if (is_string($resp) && $resp !== '') {
        $decoded = json_decode($resp, true);
    }

    debugLog([
        'event' => 'paystack.response',
        'duration_ms' => $dt,
        'http_status' => $status,
        'body' => is_array($decoded) ? $decoded : $truncate($resp),
    ], 'paystack');

    return ['status' => (int)$status, 'body' => $decoded, 'raw' => (string)$resp];
}

/**
 * Initialize a Paystack transaction and log details.
 * Example $params: ['email' => 'user@example.com', 'amount' => 50000]
 */
function paystack_initialize(array $params): array {
    return paystack_request('POST', 'transaction/initialize', $params);
}

/**
 * Verify a Paystack transaction by reference and log details.
 */
function paystack_verify(string $reference): array {
    $endpoint = 'transaction/verify/' . rawurlencode($reference);
    return paystack_request('GET', $endpoint);
}

// Email Configurations (defaults; allow overrides from .secrets.php)
if (!defined('SMTP_HOST'))     define('SMTP_HOST', 'smtp.gmail.com');
if (!defined('SMTP_SECURE'))   define('SMTP_SECURE', 'ssl'); // 'ssl' | 'tls' | ''
if (!defined('SMTP_PORT'))     define('SMTP_PORT', 465);
if (!defined('SMTP_USERNAME')) define('SMTP_USERNAME', 'kelvinantwi101@gmail.com');
if (!defined('SMTP_PASSWORD')) define('SMTP_PASSWORD', 'cerq mgzc nogd ghfo');
if (!defined('FROM_EMAIL'))    define('FROM_EMAIL', 'kelvinantwi101@gmail.com');
// Optional friendly name
if (!defined('FROM_NAME'))     define('FROM_NAME', 'RESUCHECK');

/**
 * Send email via PHPMailer using SMTP constants defined above.
 * Returns true on success, false on failure. Logs details via debugLog().
 */
function mailer_send(string $to, string $subject, string $body, bool $isHtml = false, ?string $replyTo = null): bool {
    // Load PHPMailer classes: try Composer first, then direct vendor fallback
    $autoload = __DIR__ . '/vendor/autoload.php';
    if (is_file($autoload)) {
        require_once $autoload;
    } else {
        $vbase = __DIR__ . '/vendor/phpmailer/phpmailer/src';
        if (is_file($vbase . '/PHPMailer.php')) {
            require_once $vbase . '/PHPMailer.php';
            require_once $vbase . '/SMTP.php';
            require_once $vbase . '/Exception.php';
        }
    }

    // Namespaced class
    if (!class_exists('PHPMailer\\PHPMailer\\PHPMailer')) {
        debugLog(['event' => 'mail.error', 'reason' => 'PHPMailer class not found'], 'backend');
        return false;
    }

    $mail = new PHPMailer\PHPMailer\PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host = SMTP_HOST;
        $mail->Port = (int)SMTP_PORT;
        $mail->SMTPAuth = true;
        $mail->Username = SMTP_USERNAME;
        $mail->Password = SMTP_PASSWORD;

        // Map SMTP_SECURE string to PHPMailer constant
        $secure = strtolower((string)SMTP_SECURE);
        if ($secure === 'ssl') {
            $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_SMTPS;
        } elseif ($secure === 'tls') {
            $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
        } else {
            $mail->SMTPSecure = '';
        }

        $mail->CharSet = 'UTF-8';
        $mail->setFrom(FROM_EMAIL, defined('FROM_NAME') ? FROM_NAME : '');
        if ($replyTo) {
            $mail->addReplyTo($replyTo);
        }
        $mail->addAddress($to);

        $mail->Subject = $subject;
        if ($isHtml) {
            $mail->isHTML(true);
            $mail->Body = $body;
            // Provide a basic AltBody by stripping tags
            $mail->AltBody = trim(strip_tags(str_replace(["<br>", "<br/>", "<br />"], "\n", $body)));
        } else {
            $mail->isHTML(false);
            $mail->Body = $body;
        }

        $ok = $mail->send();
        debugLog(['event' => 'mail.send', 'to' => $to, 'ok' => $ok, 'subject' => $subject], 'backend');
        return $ok;
    } catch (Throwable $e) {
        debugLog(['event' => 'mail.error', 'to' => $to, 'error' => $e->getMessage()], 'backend');
        return false;
    }
}

// Backward-compat shim: some endpoints may still call mail_send()
if (!function_exists('mail_send')) {
    /**
     * Compatibility wrapper that proxies to PHPMailer-based mailer_send().
     * Signature kept simple to match usage in this project.
     */
    function mail_send(string $to, string $subject, string $message): bool {
        return mailer_send($to, $subject, $message, false, null);
    }
}