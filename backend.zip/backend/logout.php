<?php
declare(strict_types=1);
require_once __DIR__ . '/helpers.php';

// Allow CORS like other endpoints and start the session
allow_cors();
start_session();

// Only allow POST (OPTIONS is handled inside allow_cors())
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
    json_response(['error' => 'method'], 405);
}

// Clear all session data
$_SESSION = [];
if (session_id() !== '' || isset($_COOKIE[session_name()])) {
    // Delete the session cookie
    if (PHP_VERSION_ID >= 70300) {
        @setcookie(session_name(), '', [
            'expires' => time() - 42000,
            'path' => '/',
            'domain' => '',
            'secure' => false, // set true on HTTPS
            'httponly' => true,
            'samesite' => 'Lax',
        ]);
    } else {
        @setcookie(session_name(), '', time() - 42000, '/');
    }
}

// Destroy the session
@session_unset();
@session_destroy();

json_response(['ok' => true]);
