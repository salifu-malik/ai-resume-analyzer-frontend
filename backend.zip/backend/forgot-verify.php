<?php
declare(strict_types=1);

require_once __DIR__ . '/helpers.php';

allow_cors();

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'OPTIONS') { http_response_code(204); exit; }
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
    json_response(['error' => 'method not allowed'], 405);
}

$body = require_json();
$email = trim((string)($body['email'] ?? ''));
$code  = strtoupper(trim((string)($body['code'] ?? '')));

if (!filter_var($email, FILTER_VALIDATE_EMAIL) || $code === '') {
    json_response(['error' => 'Invalid input'], 422);
}

// Frontend normalizes to A–Z0–9 and length 6; do similar sanity checks here
$code = preg_replace('/[^A-Z0-9]/', '', $code);
if (strlen($code) !== 6) {
    json_response(['error' => 'Invalid or expired code'], 400);
}

$pdo = get_pdo();

try {
    $stmt = $pdo->prepare('SELECT id, is_verify, reset_code_hash, reset_code_expires FROM users WHERE email = ?');
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if (!$user || (int)$user['is_verify'] !== 1) {
        // Generic failure to avoid revealing account state
        json_response(['error' => 'Invalid or expired code'], 400);
    }

    $expires = (int)($user['reset_code_expires'] ?? 0);
    $hash = (string)($user['reset_code_hash'] ?? '');
    if ($expires < time() || !$hash || !password_verify($code, $hash)) {
        json_response(['error' => 'Invalid or expired code'], 400);
    }

    // Valid code: issue a short-lived reset token
    $token = bin2hex(random_bytes(32)); // 64 hex chars
    $tokExp = time() + 5* 60; // 5 minutes

    $upd = $pdo->prepare('UPDATE users SET reset_token = ?, reset_token_expires = ?, reset_code_hash = NULL, reset_code_expires = NULL WHERE id = ?');
    $upd->execute([$token, $tokExp, (int)$user['id']]);

    json_response(['ok' => true, 'token' => $token]);
} catch (Throwable $e) {
    debugLog(['event' => 'forgot.verify.error', 'email' => $email, 'msg' => $e->getMessage()], 'backend');
    json_response(['error' => 'server error'], 500);
}
