<?php
declare(strict_types=1);

require_once __DIR__ . '/vendor/autoload.php';
require_once __DIR__ . '/.secrets.php';


use Hashids\Hashids;

function get_hashids(): Hashids {
    return new Hashids(HASHED_SALT, 12);
}


function encode_id(int $id): string {
    return get_hashids()->encode($id);
}

function decode_id(string $hash): ?int {
    $decoded = get_hashids()->decode($hash);
    return $decoded[0] ?? null;
}
