<?php
declare(strict_types=1);
require_once __DIR__ . '/config.php';

function require_json(): array {
    $raw = file_get_contents('php://input');
    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}

function current_user_id(): ?int {
    return $_SESSION['uid'] ?? null;
}

function require_auth(): int {
    $uid = current_user_id();
    if (!$uid) json_response(['error' => 'unauthorized'], 401);
    return $uid;
}

/**
 * Require that the current user has verified their email.
 * Responds with 403 if not verified.
 */
function require_verified(): void {
    $uid = require_auth();
    $pdo = get_pdo();
    $stmt = $pdo->prepare('SELECT is_verify FROM users WHERE id = ?');
    $stmt->execute([$uid]);
    $row = $stmt->fetch();
    if (!$row || (int)$row['is_verify'] !== 1) {
        json_response(['error' => 'account not verified'], 403);
    }
}

/**
 * For server-to-server protected endpoints. Requires header X-Server-Key matching SERVER_API_KEY.
 * Use only for private/internal APIs, not for browser-facing endpoints.
 */
function require_server_key(): void {
    $key = $_SERVER['HTTP_X_SERVER_KEY'] ?? '';
    if (!defined('SERVER_API_KEY') || SERVER_API_KEY === '' || $key !== SERVER_API_KEY) {
        json_response(['error' => 'unauthorized'], 401);
    }
}

// Send verification email using the centralized mailer in config.php
function send_verification_email(string $email, string $verifyLink): bool {
    $subject = 'Verify Your Account';
    $body = "<h2>Verify your email</h2>
            <p>Click the link below to activate your account:</p>
            
            <p><a href='" . htmlspecialchars($verifyLink, ENT_QUOTES, 'UTF-8') . "'>" . htmlspecialchars($verifyLink, ENT_QUOTES, 'UTF-8') . "</a></p>
            <p>If you didn’t create this account, ignore this email.</p>";
    // Use PHPMailer-based helper
    return mailer_send($email, $subject, $body, true, null);
}
