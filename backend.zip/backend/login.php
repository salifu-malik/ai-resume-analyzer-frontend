<?php
declare(strict_types=1);
require_once __DIR__ . '/helpers.php';
require_once __DIR__ . '/hashids.php';
allow_cors();
start_session();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_response(['error' => 'error'], 405);

$body = require_json();
$email = trim($body['email'] ?? '');
$password = $body['password'] ?? '';



$pdo = get_pdo();
$stmt = $pdo->prepare('SELECT id, password_hash, name, coins FROM users WHERE email = ?');
$stmt->execute([$email]);
$user = $stmt->fetch();

if (!$user || !password_verify($password, $user['password_hash'])) {
    json_response(['error' => 'Invalid credentials'], 401);
}

// Store real ID in session
$_SESSION['uid'] = (int)$user['id'];

// Encode the ID for frontend
$encodedId = encode_id((int)$user['id']);


$_SESSION['uid'] = (int)$user['id'];
json_response(['ok' => true, 'user' => ['id' => $encodedId, 'email' => $email, 'name' => $user['name'], 'coins' => (int)$user['coins']]]);