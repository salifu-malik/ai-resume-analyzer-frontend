<?php
declare(strict_types=1);

require_once __DIR__ . '/helpers.php';

// 1) CORS + session + auth + verification gate
allow_cors();
start_session();
$uid = require_auth();
require_verified();

// 2) Only POST JSON
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
if ($method === 'OPTIONS') { http_response_code(204); exit; }
if ($method !== 'POST') json_response(['error' => 'method not allowed'], 405);

$body = require_json();
$companyName   = trim((string)($body['companyName'] ?? ''));
$jobTitle      = trim((string)($body['jobTitle'] ?? ''));
$jobDescription= trim((string)($body['jobDescription'] ?? ''));
$imageBase64   = (string)($body['imageBase64'] ?? ''); // data URL or raw base64
$resumeText    = (string)($body['resumeText'] ?? '');   // optional text-only path

if ($companyName === '' && $jobTitle === '' && $jobDescription === '') {
    json_response(['error' => 'invalid_input', 'details' => 'missing job context'], 422);
}
if ($imageBase64 === '' && $resumeText === '') {
    json_response(['error' => 'invalid_input', 'details' => 'provide imageBase64 or resumeText'], 422);
}

// 3) Verify balance before invoking AI (avoid burning tokens when no coins)
try {
    $pdo = get_pdo();
    $stmt = $pdo->prepare('SELECT coins FROM users WHERE id = ?');
    $stmt->execute([$uid]);
    $coins = (int)$stmt->fetchColumn();
    if ($coins < 1) {
        json_response(['error' => 'insufficient_funds'], 402);
    }
} catch (Throwable $e) {
    debugLog(['event' => 'analyze.balance_check_error', 'error' => $e->getMessage()], 'backend');
    json_response(['error' => 'server_error'], 500);
}

// 4) Gemini client helpers
function get_gemini_key(): string {
    $key = env('GEMINI_API_KEY');
    if (!$key && defined('GEMINI_API_KEY') && GEMINI_API_KEY !== '') {
        $key = GEMINI_API_KEY;
    }
    if (!$key) throw new RuntimeException('GEMINI_API_KEY not set');
    return $key;
}

function gemini_headers(): array {
    return [
        'Content-Type: application/json',
        'Accept: application/json',
        'x-goog-api-key: ' . get_gemini_key(),
    ];
}

function mask_headers_for_log_ai(array $headers): array {
    return array_map(function ($h) {
        if (stripos($h, 'x-goog-api-key:') === 0) return 'x-goog-api-key: ***';
        return $h;
    }, $headers);
}

/**
 * Minimal Gemini generateContent call.
 * @return array{status:int, body:mixed, raw:string}
 */
function gemini_request(string $model, array $contentParts, array $generationConfig = []): array {
    $base = 'https://generativelanguage.googleapis.com/v1beta/models/';
    $url = $base . rawurlencode($model) . ':generateContent';
    $headers = gemini_headers();
    $masked = mask_headers_for_log_ai($headers);

    $payload = [
        'contents' => [
            [ 'role' => 'user', 'parts' => $contentParts ],
        ],
        'generationConfig' => array_merge([
            'temperature' => 0.2,
            'maxOutputTokens' => 1200,
            // Strong hint to output JSON only
            'responseMimeType' => 'application/json',
        ], $generationConfig),
    ];

    $json = json_encode($payload, JSON_UNESCAPED_SLASHES);
    debugLog(['event' => 'gemini.request', 'url' => $url, 'headers' => $masked, 'payload' => $payload], 'gemini');

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $json);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    $resp = curl_exec($ch);
    $errno = curl_errno($ch);
    $err = $errno ? curl_error($ch) : null;
    $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($errno) {
        debugLog(['event' => 'gemini.response', 'http_status' => $status, 'error' => $err, 'raw' => $resp], 'gemini');
        return ['status' => $status ?: 0, 'body' => null, 'raw' => (string)$resp];
    }
    $decoded = null;
    if (is_string($resp) && $resp !== '') {
        $decoded = json_decode($resp, true);
    }
    debugLog([
        'event' => 'gemini.response',
        'http_status' => $status,
        'body' => $decoded ?: $resp,
    ], 'gemini');
    return ['status' => $status, 'body' => $decoded, 'raw' => (string)$resp];
}

// 5) Build the prompt and schema-aligned instructions
$AI_RESPONSE_FORMAT = [
    'overallScore' => 0,
    'ATS' => [
        'score' => 0,
        'tips' => [ [ 'type' => 'good', 'tip' => '' ] ],
    ],
    'toneAndStyle' => [
        'score' => 0,
        'tips' => [ [ 'type' => 'good', 'tip' => '', 'explanation' => '' ] ],
    ],
    'content' => [
        'score' => 0,
        'tips' => [ [ 'type' => 'good', 'tip' => '', 'explanation' => '' ] ],
    ],
    'structure' => [
        'score' => 0,
        'tips' => [ [ 'type' => 'good', 'tip' => '', 'explanation' => '' ] ],
    ],
    'skills' => [
        'score' => 0,
        'tips' => [ [ 'type' => 'good', 'tip' => '', 'explanation' => '' ] ],
    ],
];

$instructions = "" .
    "You are a professional resume reviewer. " .
    "You are an expert in ATS (Applicant Tracking System) and resume analysis".
    "Please analyze and rate this resume and suggest how to improve it".
    "The rating can be low if the resume is bad".
    "Be thorough and detailed. Don't be afraid to point out any mistakes or areas for improvement".
    "If there is a lot to improve, don't hesitate to give low scores. This is to help the user to improve their resume".
    "Analyze the candidate's resume against the given role context and produce STRICT JSON ONLY (no markdown, no extra text).\n" .
    "JSON schema: " . json_encode($AI_RESPONSE_FORMAT, JSON_UNESCAPED_SLASHES) . "\n\n" .
    "Rules:\n" .
    "- Respond with valid JSON only.\n" .
    "- All numeric scores are integers from 0 to 100.\n" .
    "- For ATS.tips provide an array of objects: {type: 'good'|'improve', tip: string}.\n" .
    "- For toneAndStyle/content/structure/skills tips, use an array of {type: 'good'|'improve', tip: string, explanation: string}.\n" .
    "- Be concise but specific.\n\n" .
    "Job Context:\n" .
    "Company: {$companyName}\n" .
    "Job Title: {$jobTitle}\n" .
    "Job Description:\n{$jobDescription}\n\n" .
    "Resume: Provided below as image OCR and/or text.";

// 6) Build Gemini content
$model = 'gemini-2.0-flash'; // You can change to a pinned version (or 'gemini-2.0-pro') if you prefer

$parts = [];

// If image provided, accept data URLs (data:image/png;base64,...) or raw base64
if ($imageBase64 !== '') {
    $mt = 'image/png';
    $data = $imageBase64;
    if (strpos($imageBase64, 'data:') === 0) {
        // Parse data URL
        if (preg_match('#^data:(.*?);base64,(.*)$#', $imageBase64, $m)) {
            $mt = $m[1] ?: 'image/png';
            $data = $m[2];
        }
    }
    // Basic size limit (~4MB base64) to avoid huge payloads
    if (strlen($data) > 4 * 1024 * 1024 * 1.37) { // rough overhead factor for base64
        json_response(['error' => 'payload_too_large'], 413);
    }
    // Gemini inline image part
    $parts[] = [
        'inline_data' => [
            'mime_type' => $mt,
            'data' => $data,
        ],
    ];
}

$combinedText = $instructions;
if ($resumeText !== '') {
    $combinedText .= "\n\nResume Text (client-provided):\n" . $resumeText;
}
$parts[] = [ 'text' => $combinedText ];

// Optional but recommended: enforce JSON shape with responseSchema
$responseSchema = [
    'type' => 'object',
    'properties' => [
        'overallScore' => ['type' => 'integer'],
        'ATS' => [
            'type' => 'object',
            'properties' => [
                'score' => ['type' => 'integer'],
                'tips' => ['type' => 'array', 'items' => [
                    'type' => 'object', 'properties' => [
                        'type' => ['type' => 'string'],
                        'tip' => ['type' => 'string'],
                    ], 'required' => ['type','tip']
                ]],
            ], 'required' => ['score','tips']
        ],
        'toneAndStyle' => [
            'type' => 'object',
            'properties' => [
                'score' => ['type' => 'integer'],
                'tips' => ['type' => 'array', 'items' => [
                    'type' => 'object', 'properties' => [
                        'type' => ['type' => 'string'],
                        'tip' => ['type' => 'string'],
                        'explanation' => ['type' => 'string']
                    ], 'required' => ['type','tip','explanation']
                ]],
            ], 'required' => ['score','tips']
        ],
        'content' => [
            'type' => 'object',
            'properties' => [
                'score' => ['type' => 'integer'],
                'tips' => ['type' => 'array', 'items' => [
                    'type' => 'object', 'properties' => [
                        'type' => ['type' => 'string'],
                        'tip' => ['type' => 'string'],
                        'explanation' => ['type' => 'string']
                    ], 'required' => ['type','tip','explanation']
                ]],
            ], 'required' => ['score','tips']
        ],
        'structure' => [
            'type' => 'object',
            'properties' => [
                'score' => ['type' => 'integer'],
                'tips' => ['type' => 'array', 'items' => [
                    'type' => 'object', 'properties' => [
                        'type' => ['type' => 'string'],
                        'tip' => ['type' => 'string'],
                        'explanation' => ['type' => 'string']
                    ], 'required' => ['type','tip','explanation']
                ]],
            ], 'required' => ['score','tips']
        ],
        'skills' => [
            'type' => 'object',
            'properties' => [
                'score' => ['type' => 'integer'],
                'tips' => ['type' => 'array', 'items' => [
                    'type' => 'object', 'properties' => [
                        'type' => ['type' => 'string'],
                        'tip' => ['type' => 'string'],
                        'explanation' => ['type' => 'string']
                    ], 'required' => ['type','tip','explanation']
                ]],
            ], 'required' => ['score','tips']
        ],
    ],
    'required' => ['overallScore','ATS','toneAndStyle','content','structure','skills']
];

$genConfig = [
    'responseMimeType' => 'application/json',
    'responseSchema' => $responseSchema,
];

// 7) Call Gemini
$resp = gemini_request($model, $parts, $genConfig);
if (!is_array($resp['body'])) {
    json_response(['error' => 'ai_bad_gateway', 'status' => $resp['status'], 'raw' => $resp['raw']], 502);
}

$bodyAi = $resp['body'];
// Gemini returns candidates[0].content.parts[].text
$aiText = '';
if (isset($bodyAi['candidates'][0]['content']['parts']) && is_array($bodyAi['candidates'][0]['content']['parts'])) {
    foreach ($bodyAi['candidates'][0]['content']['parts'] as $p) {
        if (isset($p['text'])) { $aiText .= (string)$p['text']; }
    }
}
$aiText = trim($aiText);
if ($aiText === '') {
    json_response(['error' => 'ai_empty_response', 'raw' => $bodyAi], 502);
}

// 8) Parse JSON from AI
$feedback = null;
try {
    $feedback = json_decode($aiText, true, 512, JSON_THROW_ON_ERROR);
} catch (Throwable $e) {
    // Sometimes models wrap JSON or add stray characters; try to extract the first {...} block
    if (preg_match('/\{[\s\S]*\}/', $aiText, $m)) {
        try { $feedback = json_decode($m[0], true, 512, JSON_THROW_ON_ERROR); } catch (Throwable $e2) {}
    }
}

if (!is_array($feedback)) {
    debugLog(['event' => 'ai.parse_error', 'sample' => substr($aiText, 0, 4000)], 'gemini');
    json_response(['error' => 'ai_invalid_json'], 502);
}

// 9) Debit 1 coin directly (in-process) using PDO — no HTTP self-call
try {
    $pdo = get_pdo();
    $pdo->beginTransaction();

    // Lock the user row and read balance
    $stmt = $pdo->prepare('SELECT coins FROM users WHERE id = ? FOR UPDATE');
    $stmt->execute([$uid]);
    $coins = (int)$stmt->fetchColumn();

    if ($coins < 1) {
        $pdo->rollBack();
        json_response(['error' => 'insufficient_funds_after', 'feedback' => $feedback], 402);
    }

    // Atomic debit
    $upd = $pdo->prepare('UPDATE users SET coins = coins - 1 WHERE id = ? AND coins >= 1');
    $upd->execute([$uid]);
    if ($upd->rowCount() !== 1) {
        $pdo->rollBack();
        json_response(['error' => 'insufficient_funds_after', 'feedback' => $feedback], 402);
    }

    // Insert a debit transaction. Adjust columns to match your schema.
    // If your transactions table requires additional columns, supply NULL/defaults as needed.
    $ins = $pdo->prepare('INSERT INTO transactions (
        user_id, type, amount, currency, description, provider,
        paystack_reference, paystack_status, paystack_authorization_code, meta
    ) VALUES (
        ?, "debit", ?, "GHS", ?, "app",
        NULL, NULL, NULL, NULL
    )');
    $ins->execute([$uid, 1, 'Resume analysis']);

    $pdo->commit();
} catch (Throwable $e) {
    if ($pdo && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    debugLog(['event' => 'analyze.debit_error', 'uid' => $uid, 'error' => $e->getMessage()], 'backend');
    json_response(['error' => 'spend_failed_internal', 'feedback' => $feedback], 500);
}

// 10) Success
json_response([
    'ok' => true,
    'feedback' => $feedback,
    'usage' => [
        'prompt_tokens' => $bodyAi['usageMetadata']['promptTokenCount'] ?? null,
        'candidates_tokens' => $bodyAi['usageMetadata']['candidatesTokenCount'] ?? null,
        'total_tokens' => $bodyAi['usageMetadata']['totalTokenCount'] ?? null,
    ],
]);