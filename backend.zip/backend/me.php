<?php
declare(strict_types=1);
require_once __DIR__ . '/helpers.php';
require_once __DIR__ . '/hashids.php';
allow_cors();
start_session();

$uid = require_auth();
$pdo = get_pdo();
$stmt = $pdo->prepare('SELECT id, email, name, coins FROM users WHERE id = ?');
$stmt->execute([$uid]);
$user = $stmt->fetch();
if (!$user) json_response(['error' => 'not found'], 404);

$encodedId = encode_id((int)$user['id']);

json_response(['user' => ['id' => $encodedId,
                         'email' => $user['email'],
                        'name' => $user['name'],
                        'coins' => (int)$user['coins']
]]);