<?php
declare(strict_types=1);
require_once __DIR__ . '/helpers.php';
require_once __DIR__ . '/hashids.php';

allow_cors();
start_session();

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
if ($method === 'OPTIONS') { http_response_code(204); exit; }

$uid = require_auth();
$pdo = get_pdo();

// GET: fetch profile (no verification required to view)
if ($method === 'GET') {
    $stmt = $pdo->prepare('SELECT id, email, name FROM users WHERE id = ?');
    $stmt->execute([$uid]);
    $user = $stmt->fetch();
    if (!$user) json_response(['error' => 'not_found'], 404);

    $encodedId = encode_id((int)$user['id']);
    json_response([
        'ok' => true,
        'user' => [
            'id' => $encodedId,
            'email' => $user['email'],
            'name' => $user['name'],
        ],
    ]);
}

// Only allow POST for updates
if ($method !== 'POST') {
    json_response(['error' => 'method not allowed'], 405);
}

// POST: update profile (requires verified account)
require_verified();

$data = require_json();

// Disallow email updates explicitly
if (isset($data['email']) && $data['email'] !== null) {
    json_response(['error' => 'email_immutable'], 422);
}

$newName = isset($data['name']) ? trim((string)$data['name']) : null;
$currentPassword = isset($data['current_password']) ? (string)$data['current_password'] : null;
$newPassword = isset($data['new_password']) ? (string)$data['new_password'] : null;
$confirmPassword = isset($data['confirm_password']) ? (string)$data['confirm_password'] : null;

$doNameChange = $newName !== null;
$doPasswordChange = $newPassword !== null || $confirmPassword !== null || $currentPassword !== null;

if (!$doNameChange && !$doPasswordChange) {
    json_response(['error' => 'No changes made'], 422);
}

if ($doNameChange) {
    if ($newName === '') {
        json_response(['error' => 'invalid_name'], 422);
    }
    if (mb_strlen($newName) > 255) {
        $newName = mb_substr($newName, 0, 255);
    }
}

if ($doPasswordChange) {
    if (!$currentPassword || !$newPassword || !$confirmPassword) {
        json_response(['error' => 'password_fields_required'], 422);
    }
    if ($newPassword !== $confirmPassword) {
        json_response(['error' => 'password_mismatch'], 422);
    }
    if (strlen($newPassword) < 6) {
        json_response(['error' => 'weak_password', 'min' => 6], 422);
    }
}

try {
    $pdo->beginTransaction();

    // Fetch current user (and password_hash if needed)
    if ($doPasswordChange) {
        $stmt = $pdo->prepare('SELECT password_hash FROM users WHERE id = ? FOR UPDATE');
        $stmt->execute([$uid]);
        $row = $stmt->fetch();
        if (!$row) {
            $pdo->rollBack();
            json_response(['error' => 'not_found'], 404);
        }
        if (!password_verify($currentPassword, $row['password_hash'])) {
            $pdo->rollBack();
            json_response(['error' => 'invalid current password'], 401);
        }
    } else {
        // Lock row to serialize concurrent updates to name
        $stmt = $pdo->prepare('SELECT id FROM users WHERE id = ? FOR UPDATE');
        $stmt->execute([$uid]);
        if (!$stmt->fetch()) {
            $pdo->rollBack();
            json_response(['error' => 'Not found'], 404);
        }
    }

    // Build update statement dynamically
    $sets = [];
    $params = [];
    if ($doNameChange) {
        $sets[] = 'name = ?';
        $params[] = $newName;
    }
    if ($doPasswordChange) {
        $sets[] = 'password_hash = ?';
        $params[] = password_hash($newPassword, PASSWORD_DEFAULT);
    }

    if (!$sets) {
        $pdo->rollBack();
        json_response(['error' => 'no_changes'], 422);
    }

    $params[] = $uid;
    $sql = 'UPDATE users SET ' . implode(', ', $sets) . ' WHERE id = ?';
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);

    // Fetch updated fields to return
    $stmt = $pdo->prepare('SELECT id, email, name FROM users WHERE id = ?');
    $stmt->execute([$uid]);
    $user = $stmt->fetch();

    $pdo->commit();

    debugLog([
        'event' => 'profile.updated',
        'uid' => $uid,
        'name_changed' => $doNameChange,
        'password_changed' => $doPasswordChange,
    ], 'backend');

    $encodedId = encode_id((int)$user['id']);
    json_response([
        'ok' => true,
        'user' => [
            'id' => $encodedId,
            'email' => $user['email'],
            'name' => $user['name'],
        ],
    ]);
} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    debugLog(['event' => 'profile.error', 'uid' => $uid, 'msg' => $e->getMessage()], 'backend');
    json_response(['error' => 'server_error'], 500);
}

