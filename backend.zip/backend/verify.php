<?php
declare(strict_types=1);
require_once __DIR__ . '/helpers.php';


$pdo = get_pdo();

$token = $_GET['token'] ?? '';

if (!$token) {
    header('Location: http://localhost:5173/verifyFailed'); // redirect to failed page
    exit;
}

$stmt = $pdo->prepare("SELECT id, is_verify FROM users WHERE verify_token = ?");
$stmt->execute([$token]);
$user = $stmt->fetch();

if (!$user) {
    header('Location: http://localhost:5173/verifyFailed');
    exit;
}

if ((int)$user['is_verify'] === 1) {
    header('Location: http://localhost:5173/verifyExpired'); // already verified
    exit;
}

// Mark user as verified
$stmt = $pdo->prepare("UPDATE users SET is_verify = 1, verify_token = NULL WHERE id = ?");
$stmt->execute([$user['id']]);

// Redirect to frontend success page
header('Location: http://localhost:5173/verifySuccess');
exit;