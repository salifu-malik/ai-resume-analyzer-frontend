<?php
declare(strict_types=1);

require_once __DIR__ . '/helpers.php';
require_once __DIR__ . '/hashids.php';


allow_cors();
start_session();

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
if ($method !== 'POST') {
    header('Allow: POST');
    json_response(['error' => 'method not allowed'], 405);
}

$body = require_json();
$email = trim($body['email'] ?? '');
$password = $body['password'] ?? '';
$confirm  = $body['confirm_password'] ?? '';
$name = trim($body['name'] ?? '');

// Validation
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) json_response(['error' => 'invalid email'], 422);
if (strlen($password) < 6) json_response(['error' => 'Weak Password'], 422);
if ($confirm === '') json_response(['error' => 'Confirm Password Required'], 422);
if ($password !== $confirm) json_response(['error' => 'Password Mismatch'], 422);

$pdo = get_pdo();

// Check if email exists
$stmt = $pdo->prepare('SELECT id FROM users WHERE email = ?');
$stmt->execute([$email]);
if ($stmt->fetch()) json_response(['error' => 'Email already exists'], 409);

// Hash password
//$hash = password_hash($password, PASSWORD_ARGON2ID, [
//    'memory_cost' => 1 << 17, // 131,072 KB
//    'time_cost'   => 4,
//    'threads'     => 2
//]);

$token = bin2hex(random_bytes(32));
    $expires = time() + 3600; //

$hash = password_hash($password, PASSWORD_DEFAULT);


// Insert user normally
$stmt = $pdo->prepare(
    'INSERT INTO users (email, password_hash, name, is_verify, verify_token, verify_expires) VALUES (?, ?, ?, 0, ?, ?)'
);
$stmt->execute([$email, $hash, $name, $token, $expires]);

// Auto-increment ID
$uid = (int) $pdo->lastInsertId();

// ENCODE the ID for frontend
$encodedId = encode_id($uid);

// Auto-login
$_SESSION['uid'] = $uid;

// Verification link
$verifyLink = "http://localhost/backend/verify?token=$token";

// Send verification email via centralized helper (HTML email)
send_verification_email($email, $verifyLink);

    json_response([
        'ok' => true,
        'id' => $encodedId,    // send HASHED id
        'email' => $email,
        'name' => $name,
        'coins' => 0,
        'verified' => false
    ]);
