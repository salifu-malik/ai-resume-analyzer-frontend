<?php
declare(strict_types=1);
require_once __DIR__ . '/helpers.php';

// Public endpoint (no auth). Verify the code and allow password change.
allow_cors();
start_session();

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
if ($method === 'OPTIONS') { http_response_code(204); exit; }
if ($method !== 'POST') json_response(['error' => 'method'], 405);

$body = require_json();
$email = strtolower(trim((string)($body['email'] ?? '')));
$code = strtoupper(trim((string)($body['code'] ?? '')));
$new = (string)($body['new_password'] ?? '');
$confirm = (string)($body['confirm_password'] ?? '');

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    json_response(['error' => 'invalid_input', 'details' => ['email' => true]], 422);
}
if ($code === '' || strlen($code) !== 6) {
    json_response(['error' => 'invalid_input', 'details' => ['code' => true]], 422);
}
if (strlen($new) < 6) {
    json_response(['error' => 'weak_password'], 422);
}
if ($new !== $confirm) {
    json_response(['error' => 'password_mismatch'], 422);
}

$pdo = get_pdo();

// Fetch latest reset entry for this email
$stmt = $pdo->prepare('SELECT id, code_hash, expires_at, attempts FROM password_resets WHERE email = ? ORDER BY id DESC LIMIT 1');
$stmt->execute([$email]);
$row = $stmt->fetch();
if (!$row) {
    // No code requested or already used
    json_response(['error' => 'invalid_code'], 400);
}

$expiresAt = DateTime::createFromFormat('Y-m-d H:i:s', (string)$row['expires_at']) ?: new DateTime('@0');
$now = new DateTime('now');
if ($now > $expiresAt) {
    // Expired: delete to prevent reuse
    try { $pdo->prepare('DELETE FROM password_resets WHERE id = ?')->execute([(int)$row['id']]); } catch (Throwable $e) {}
    json_response(['error' => 'expired'], 400);
}

$attempts = (int)$row['attempts'];
if ($attempts >= 5) {
    json_response(['error' => 'rate_limited'], 429);
}

$ok = password_verify($code, (string)$row['code_hash']);
if (!$ok) {
    try {
        $pdo->prepare('UPDATE password_resets SET attempts = attempts + 1 WHERE id = ?')->execute([(int)$row['id']]);
    } catch (Throwable $e) {}
    json_response(['error' => 'invalid_code'], 400);
}

// Update user password and consume the reset entry atomically
try {
    $pdo->beginTransaction();

    // Update password (only if user exists)
    $sel = $pdo->prepare('SELECT id FROM users WHERE email = ? LIMIT 1');
    $sel->execute([$email]);
    $user = $sel->fetch();
    if (!$user) {
        // For security, still consume the reset and return generic error
        $pdo->prepare('DELETE FROM password_resets WHERE id = ?')->execute([(int)$row['id']]);
        $pdo->commit();
        json_response(['error' => 'invalid_code'], 400);
    }

    $hash = password_hash($new, PASSWORD_DEFAULT);
    $upd = $pdo->prepare('UPDATE users SET password_hash = ? WHERE id = ?');
    $upd->execute([$hash, (int)$user['id']]);

    // Consume the reset entry
    $pdo->prepare('DELETE FROM password_resets WHERE id = ?')->execute([(int)$row['id']]);

    $pdo->commit();
} catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    debugLog(['event' => 'password_reset.verify_error', 'email' => $email, 'error' => $e->getMessage()], 'backend');
    json_response(['error' => 'server_error'], 500);
}

debugLog(['event' => 'password_reset.changed', 'email' => $email], 'backend');
json_response(['ok' => true]);
