<?php
declare(strict_types=1);
require_once __DIR__ . '/helpers.php';
($__secrets = __DIR__ . '/.secrets.php') && is_file($__secrets) && @include_once $__secrets;


allow_cors();
start_session();

//$serverKey = $_SERVER['HTTP_X_SERVER_KEY'] ?? '';
//if (!defined('SERVER_API_KEY') || $serverKey !== SERVER_API_KEY) {
//    json_response(['error' => 'unauthorized', 'message' => 'Invalid server key'], 401);
//}

$uid = require_auth();
require_verified();

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
    json_response(['error' => 'method not allowed'], 405);
}

$body = require_json();
$email = trim((string)($body['email'] ?? ''));
$amount = (int)($body['amount'] ?? 0); // smallest unit (pesewas)
$metadata = isset($body['metadata']) && is_array($body['metadata']) ? $body['metadata'] : [];
$reqCurrency = isset($body['currency']) && is_string($body['currency']) ? strtoupper($body['currency']) : 'GHS';

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    json_response(['error' => 'invalid_input', 'details' => ['email' => true]], 422);
}

// Hard enforcement: 1 coin costs GHS 5.00 = 500 pesewas
if (!defined('PRICE_IN_PESWAS_PER_COIN')) {
    define('PRICE_IN_PESWAS_PER_COIN', 500);
}

// Only allow GHS
if ($reqCurrency !== 'GHS') {
    json_response(['error' => 'invalid_currency', 'expected' => 'GHS', 'got' => $reqCurrency], 422);
}

// Only allow the exact fixed price for one coin
if ($amount !== PRICE_IN_PESWAS_PER_COIN) {
    json_response([
        'error' => 'invalid_amount',
        'message' => 'Only 1-coin purchases are supported. Amount must be exactly (GHS 5.00).',
        'expected' => PRICE_IN_PESWAS_PER_COIN,
        'got' => $amount,
    ], 422);
}

// Attach useful metadata (e.g., user id) without exposing secrets
$metadata = array_merge([
    'uid' => $uid,
    'source' => 'react-frontend',
    'plan' => 'Resume Review (1 coin)',
    'coins' => 1,
    'unit_price_pesewas' => PRICE_IN_PESWAS_PER_COIN,
], $metadata);

$params = [
    'email' => $email,
    'amount' => PRICE_IN_PESWAS_PER_COIN,
    'currency' => 'GHS',
    'metadata' => $metadata,
];

// Optional callback URL passthrough
if (isset($body['callback_url']) && is_string($body['callback_url']) && $body['callback_url'] !== '') {
    $params['callback_url'] = $body['callback_url'];
}

$resp = paystack_initialize($params);

if (!is_array($resp['body'])) {
    json_response([
        'ok' => false,
        'http_status' => $resp['status'],
        'error' => 'bad_gateway',
        'raw' => $resp['raw'],
    ], 502);
}

json_response([
    'ok' => true,
    'http_status' => $resp['status'],
    'paystack' => $resp['body'],
]);


