<?php
declare(strict_types=1);
require_once __DIR__ . '/helpers.php';
allow_cors();
start_session();

$uid = require_auth();
$pdo = get_pdo();
$stmt = $pdo->prepare('SELECT id, type, amount, description, created_at FROM transactions WHERE user_id = ? ORDER BY id DESC LIMIT 200');
$stmt->execute([$uid]);
json_response(['items' => $stmt->fetchAll()]);